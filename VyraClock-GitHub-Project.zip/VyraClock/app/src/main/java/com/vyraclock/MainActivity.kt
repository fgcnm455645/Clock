package com.vyraclock

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.vyraclock.widget.ClockWidgetProvider
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("clock_settings", MODE_PRIVATE) }
    private lateinit var sizeLabel: TextView
    private lateinit var color1Label: TextView
    private lateinit var color2Label: TextView
    private var color1 = 0xFFD6B4FF.toInt()
    private var color2 = 0xFF8BC7FF.toInt()
    private val fontRequest = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        color1 = prefs.getInt("color1", color1)
        color2 = prefs.getInt("color2", color2)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(Color.rgb(250, 249, 255))
        }
        root.addView(TextView(this).apply {
            text = "Vyra Clock"
            textSize = 30f
            setTextColor(Color.rgb(35, 28, 48))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "ساعت شفاف و سفارشی برای ویجت‌ها\nتنظیمات را تغییر بده و سپس ویجت را اضافه کن."
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(8), 0, dp(20))
        })
        val preview = TextView(this).apply {
            text = "09:41"
            textSize = prefs.getInt("font_size", 48).toFloat()
            gravity = Gravity.CENTER
            setTextColor(color1)
            setPadding(0, dp(10), 0, dp(10))
        }
        root.addView(preview, LinearLayout.LayoutParams(-1, dp(105)))
        sizeLabel = TextView(this).apply { textSize = 15f; setTextColor(Color.DKGRAY) }
        root.addView(sizeLabel)
        root.addView(SeekBar(this).apply {
            max = 100
            progress = prefs.getInt("font_size", 48) - 20
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val size = progress + 20
                    prefs.edit().putInt("font_size", size).apply()
                    sizeLabel.text = "اندازه فونت: $size"
                    preview.textSize = size.toFloat()
                    refreshWidgets()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        })
        sizeLabel.text = "اندازه فونت: ${prefs.getInt("font_size", 48)}"
        root.addView(makeButton("وارد کردن فونت TTF / OTF") { openFontPicker() })
        root.addView(makeButton("رنگ اول گرادیانت: انتخاب رنگ") {
            color1 = nextColor(color1)
            prefs.edit().putInt("color1", color1).apply()
            preview.setTextColor(color1)
            refreshWidgets()
            Toast.makeText(this, "رنگ اول تغییر کرد", Toast.LENGTH_SHORT).show()
        })
        root.addView(makeButton("رنگ دوم گرادیانت: انتخاب رنگ") {
            color2 = nextColor(color2)
            prefs.edit().putInt("color2", color2).apply()
            refreshWidgets()
            Toast.makeText(this, "رنگ دوم تغییر کرد", Toast.LENGTH_SHORT).show()
        })
        root.addView(makeButton("به‌روزرسانی ویجت‌ها") { refreshWidgets(); Toast.makeText(this, "تنظیمات ذخیره شد", Toast.LENGTH_SHORT).show() })
        root.addView(TextView(this).apply {
            text = "راهنما: از صفحه اصلی وارد Widgets شوید و Vyra Clock را اضافه کنید. برای LockStar، باید نسخه One UI و پشتیبانی آن از این نوع ویجت اجازه دهد. اندازه کلی را با تغییر اندازه ویجت تنظیم کن."
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(0, dp(16), 0, 0)
        })
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(5) }
    }

    private fun openFontPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "font/*"
        }
        try { startActivityForResult(intent, fontRequest) } catch (_: Exception) {
            val fallback = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
            startActivityForResult(fallback, fontRequest)
        }
    }

    @Deprecated("Deprecated in Android API, still supported for this minimal project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != fontRequest || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                val target = File(filesDir, "custom_clock_font.ttf")
                FileOutputStream(target).use { output -> input.copyTo(output) }
                prefs.edit().putString("font_path", target.absolutePath).apply()
            }
            refreshWidgets()
            Toast.makeText(this, "فونت وارد شد", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "خواندن فونت ناموفق بود: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun refreshWidgets() {
        val manager = AppWidgetManager.getInstance(this)
        val ids = manager.getAppWidgetIds(ComponentName(this, ClockWidgetProvider::class.java))
        if (ids.isNotEmpty()) ClockWidgetProvider().onUpdate(this, manager, ids)
    }

    private fun nextColor(current: Int): Int {
        val palette = intArrayOf(0xFFD6B4FF.toInt(), 0xFF8BC7FF.toInt(), 0xFFFFB4C8.toInt(), 0xFFFFD58A.toInt(), 0xFFB7F0D1.toInt(), Color.WHITE)
        return palette[(palette.indexOf(current).coerceAtLeast(-1) + 1) % palette.size]
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
