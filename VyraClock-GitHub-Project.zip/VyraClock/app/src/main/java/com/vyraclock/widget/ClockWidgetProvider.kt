package com.vyraclock.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.widget.RemoteViews
import com.vyraclock.R
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ClockWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.clock_widget)
            views.setImageViewBitmap(R.id.clock_image, renderClock(context))
            manager.updateAppWidget(id, views)
        }
        scheduleMinuteUpdates(context)
    }

    override fun onEnabled(context: Context) { scheduleMinuteUpdates(context) }

    override fun onDisabled(context: Context) {
        val intent = Intent(context, ClockWidgetProvider::class.java).setAction(ACTION_TICK)
        val pending = PendingIntent.getBroadcast(context, 1001, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TICK) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, ClockWidgetProvider::class.java))
            if (ids.isNotEmpty()) onUpdate(context, manager, ids)
        }
    }

    private fun scheduleMinuteUpdates(context: Context) {
        val intent = Intent(context, ClockWidgetProvider::class.java).setAction(ACTION_TICK)
        val pending = PendingIntent.getBroadcast(context, 1001, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.setInexactRepeating(AlarmManager.RTC, System.currentTimeMillis() + 60_000L, 60_000L, pending)
    }

    private fun renderClock(context: Context): Bitmap {
        val prefs = context.getSharedPreferences("clock_settings", Context.MODE_PRIVATE)
        val size = prefs.getInt("font_size", 48).coerceIn(20, 120)
        val first = prefs.getInt("color1", 0xFFD6B4FF.toInt())
        val second = prefs.getInt("color2", 0xFF8BC7FF.toInt())
        val time = SimpleDateFormat("hh:mm", Locale.getDefault()).format(Date())
        val scale = context.resources.displayMetrics.density
        val width = (size * 3.8f * scale).toInt().coerceAtLeast(240)
        val height = (size * 1.7f * scale).toInt().coerceAtLeast(100)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val fontPath = prefs.getString("font_path", null)
        val typeface = try { if (fontPath != null && File(fontPath).exists()) Typeface.createFromFile(fontPath) else Typeface.create("sans-serif", Typeface.NORMAL) } catch (_: Exception) { Typeface.create("sans-serif", Typeface.NORMAL) }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.typeface = typeface
            textSize = size * scale
            textAlign = Paint.Align.CENTER
            shader = LinearGradient(0f, 0f, width.toFloat(), 0f, first, second, Shader.TileMode.CLAMP)
        }
        val y = (height - (paint.descent() + paint.ascent())) / 2f
        canvas.drawText(time, width / 2f, y, paint)
        return bitmap
    }

    companion object { private const val ACTION_TICK = "com.vyraclock.action.MINUTE_TICK" }
}
