package com.vyraclock.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.widget.RemoteViews
import com.vyraclock.R
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

class ClockWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.clock_widget)
            val options = manager.getAppWidgetOptions(id)
            val density = context.resources.displayMetrics.density
            val widthDp = max(options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH), options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH)).coerceAtLeast(110)
            val heightDp = max(options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT), options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT)).coerceAtLeast(42)
            views.setImageViewBitmap(R.id.clock_image, renderClock(context, (widthDp * density).toInt(), (heightDp * density).toInt()))
            manager.updateAppWidget(id, views)
        }
        scheduleMinuteUpdates(context)
    }

    override fun onAppWidgetOptionsChanged(context: Context, manager: AppWidgetManager, appWidgetId: Int, newOptions: android.os.Bundle) {
        onUpdate(context, manager, intArrayOf(appWidgetId))
    }

    override fun onEnabled(context: Context) { scheduleMinuteUpdates(context) }
    override fun onDisabled(context: Context) {
        val intent = Intent(context, ClockWidgetProvider::class.java).setAction(ACTION_TICK)
        val pending = PendingIntent.getBroadcast(context, 1001, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
    }
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TICK) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, ClockWidgetProvider::class.java))
            if (ids.isNotEmpty()) onUpdate(context, manager, ids)
        }
    }
    private fun scheduleMinuteUpdates(context: Context) {
        val intent = Intent(context, ClockWidgetProvider::class.java).setAction(ACTION_TICK)
        val pending = PendingIntent.getBroadcast(context, 1001, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.setInexactRepeating(AlarmManager.RTC, System.currentTimeMillis() + 60_000L, 60_000L, pending)
    }

    private fun renderClock(context: Context, width: Int, height: Int): Bitmap {
        val prefs = context.getSharedPreferences("clock_settings", Context.MODE_PRIVATE)
        val requestedSize = prefs.getInt("font_size", 64).coerceIn(20, 400)
        val first = prefs.getInt("color1", 0xFFD6B4FF.toInt())
        val second = prefs.getInt("color2", 0xFF8BC7FF.toInt())
        val direction = prefs.getInt("gradient_direction", 0).coerceIn(0, 5)
        val intensity = prefs.getInt("gradient_intensity", 100).coerceIn(0, 100) / 100f
        val time = SimpleDateFormat("hh:mm", Locale.getDefault()).format(Date())
        val bitmap = Bitmap.createBitmap(width.coerceAtLeast(1), height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val fontPath = prefs.getString("font_path", null)
        val typeface = try { if (fontPath != null && File(fontPath).exists()) Typeface.createFromFile(fontPath) else Typeface.create("sans-serif", Typeface.NORMAL) } catch (_: Exception) { Typeface.create("sans-serif", Typeface.NORMAL) }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply { this.typeface = typeface; textAlign = Paint.Align.CENTER }
        val availableWidth = width * 0.96f
        val availableHeight = height * 0.90f
        paint.textSize = requestedSize * context.resources.displayMetrics.scaledDensity
        val bounds = android.graphics.Rect()
        paint.getTextBounds(time, 0, time.length, bounds)
        val widthFit = availableWidth / max(paint.measureText(time), 1f)
        val heightFit = availableHeight / max(bounds.height().toFloat(), 1f)
        paint.textSize *= minOf(1f, widthFit, heightFit)
        paint.getTextBounds(time, 0, time.length, bounds)
        val x1: Float; val y1: Float; val x2: Float; val y2: Float
        when (direction) {
            1 -> { x1 = width.toFloat(); y1 = 0f; x2 = 0f; y2 = 0f }
            2 -> { x1 = 0f; y1 = 0f; x2 = 0f; y2 = height.toFloat() }
            3 -> { x1 = 0f; y1 = height.toFloat(); x2 = 0f; y2 = 0f }
            4 -> { x1 = 0f; y1 = 0f; x2 = width.toFloat(); y2 = height.toFloat() }
            5 -> { x1 = 0f; y1 = height.toFloat(); x2 = width.toFloat(); y2 = 0f }
            else -> { x1 = 0f; y1 = 0f; x2 = width.toFloat(); y2 = 0f }
        }
        val solid = blend(first, second, 0.5f)
        paint.shader = if (intensity <= 0f) null else LinearGradient(x1, y1, x2, y2, solid, blend(first, second, intensity), Shader.TileMode.CLAMP)
        if (paint.shader == null) paint.color = first
        val baseline = (height - (paint.descent() + paint.ascent())) / 2f
        canvas.drawText(time, width / 2f, baseline, paint)
        return bitmap
    }

    private fun blend(a: Int, b: Int, ratio: Float): Int {
        val r = ratio.coerceIn(0f, 1f)
        return Color.argb(255,
            (Color.red(a) + (Color.red(b) - Color.red(a)) * r).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * r).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * r).toInt())
    }
    companion object { private const val ACTION_TICK = "com.vyraclock.action.MINUTE_TICK" }
}
