package com.vyraclock

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.vyraclock.widget.ClockWidgetProvider
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("clock_settings", MODE_PRIVATE) }
    private var color1 = 0xFFD6B4FF.toInt()
    private var color2 = 0xFF8BC7FF.toInt()
    private var direction = 0
    private var intensity = 100
    private val fontRequest = 42
    private lateinit var preview: TextView
    private lateinit var color1Label: TextView
    private lateinit var color2Label: TextView
    private lateinit var sizeLabel: TextView
    private val directions = arrayOf("چپ به راست", "راست به چپ", "بالا به پایین", "پایین به بالا", "مورب ↘", "مورب ↗")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        color1 = prefs.getInt("color1", color1)
        color2 = prefs.getInt("color2", color2)
        direction = prefs.getInt("gradient_direction", 0).coerceIn(0, directions.lastIndex)
        intensity = prefs.getInt("gradient_intensity", 100).coerceIn(0, 100)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(24))
            setBackgroundColor(Color.rgb(250, 249, 255))
        }
        root.addView(TextView(this).apply { text = "Vyra Clock"; textSize = 30f; setTextColor(Color.rgb(35, 28, 48)); typeface = Typeface.DEFAULT_BOLD })
        root.addView(TextView(this).apply {
            text = "ساعت شفاف با فونت و گرادیانت دلخواه\nتنظیمات را تغییر بده و ویجت را تازه‌سازی کن."
            textSize = 15f; setTextColor(Color.DKGRAY); setPadding(0, dp(8), 0, dp(10))
        })
        preview = TextView(this).apply {
            text = "09:41"; textSize = prefs.getInt("font_size", 64).toFloat(); gravity = Gravity.CENTER
            setTextColor(color1); setPadding(dp(4), dp(8), dp(4), dp(8)); includeFontPadding = true
        }
        root.addView(preview, LinearLayout.LayoutParams(-1, dp(130)))
        sizeLabel = label(root, "اندازه فونت")
        addSeek(root, "اندازه فونت", 20, 400, prefs.getInt("font_size", 64), "") { value ->
            prefs.edit().putInt("font_size", value).apply(); sizeLabel.text = "اندازه فونت: $value"; preview.textSize = value.toFloat(); refreshWidgets()
        }
        sizeLabel.text = "اندازه فونت: ${prefs.getInt("font_size", 64)} sp"
        root.addView(makeButton("وارد کردن فونت TTF / OTF") { openFontPicker() })
        color1Label = label(root, "رنگ اول گرادیانت")
        addSeek(root, "رنگ اول — طیف رنگ", 0, 359, hue(color1), "°") { value ->
            color1 = withAlpha(Color.HSVToColor(floatArrayOf(value.toFloat(), 0.62f, 1f)), 255)
            prefs.edit().putInt("color1", color1).apply(); updateColorLabels(); refreshWidgets()
        }
        color2Label = label(root, "رنگ دوم گرادیانت")
        addSeek(root, "رنگ دوم — طیف رنگ", 0, 359, hue(color2), "°") { value ->
            color2 = withAlpha(Color.HSVToColor(floatArrayOf(value.toFloat(), 0.62f, 1f)), 255)
            prefs.edit().putInt("color2", color2).apply(); updateColorLabels(); refreshWidgets()
        }
        updateColorLabels()
        root.addView(TextView(this).apply { text = "جهت گرادیانت"; textSize = 16f; setTextColor(Color.DKGRAY); setPadding(0, dp(12), 0, dp(4)) })
        root.addView(makeButton("جهت فعلی: ${directions[direction]}  •  تغییر جهت") {
            direction = (direction + 1) % directions.size
            prefs.edit().putInt("gradient_direction", direction).apply()
            (it as Button).text = "جهت فعلی: ${directions[direction]}  •  تغییر جهت"
            refreshWidgets()
        })
        addSeek(root, "شدت گرادیانت", 0, 100, intensity, "%") { value ->
            intensity = value; prefs.edit().putInt("gradient_intensity", value).apply(); refreshWidgets()
        }
        root.addView(makeButton("به‌روزرسانی ویجت‌ها") { refreshWidgets(); Toast.makeText(this, "تنظیمات ذخیره شد", Toast.LENGTH_SHORT).show() })
        root.addView(TextView(this).apply {
            text = "نکته: ویجت پس‌زمینه شفاف دارد. اندازهٔ نهایی را از تنظیمات اندازهٔ ویجت در صفحهٔ اصلی یا LockStar تغییر بده. فونت‌های خیلی بزرگ ممکن است با محدودیت فضای خود ویجت روبه‌رو شوند."
            textSize = 13f; setTextColor(Color.GRAY); setPadding(0, dp(16), 0, 0)
        })
        setContentView(root)
    }

    private fun label(parent: LinearLayout, initial: String): TextView = TextView(this).apply {
        text = initial; textSize = 14f; setTextColor(Color.DKGRAY); setPadding(0, dp(6), 0, 0); parent.addView(this)
    }

    private fun addSeek(parent: LinearLayout, title: String, min: Int, max: Int, initial: Int, suffix: String, onValue: (Int) -> Unit) {
        val text = TextView(this).apply { text = "$title: $initial$suffix"; textSize = 14f; setTextColor(Color.DKGRAY); setPadding(0, dp(8), 0, 0) }
        parent.addView(text)
        parent.addView(SeekBar(this).apply {
            this.max = max - min
            progress = (initial - min).coerceIn(0, this.max)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = progress + min
                    text.text = "$title: $value$suffix"
                    if (fromUser) onValue(value)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        })
    }

    private fun makeButton(label: String, action: (Button) -> Unit) = Button(this).apply {
        text = label; isAllCaps = false
        setOnClickListener { action(this) }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(5) }
    }

    private fun openFontPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        startActivityForResult(intent, fontRequest)
    }

    @Deprecated("Deprecated API kept for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != fontRequest || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                val target = File(filesDir, "custom_clock_font.ttf")
                FileOutputStream(target).use { output -> input.copyTo(output) }
                prefs.edit().putString("font_path", target.absolutePath).apply()
            }
            refreshWidgets(); Toast.makeText(this, "فونت وارد شد", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "خواندن فونت ناموفق بود: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun updateColorLabels() {
        color1Label.text = "رنگ اول گرادیانت  •  #${Integer.toHexString(color1).takeLast(6).uppercase()}"
        color2Label.text = "رنگ دوم گرادیانت  •  #${Integer.toHexString(color2).takeLast(6).uppercase()}"
        color1Label.setTextColor(color1); color2Label.setTextColor(color2)
    }

    private fun refreshWidgets() {
        val manager = AppWidgetManager.getInstance(this)
        val ids = manager.getAppWidgetIds(ComponentName(this, ClockWidgetProvider::class.java))
        if (ids.isNotEmpty()) ClockWidgetProvider().onUpdate(this, manager, ids)
    }

    private fun hue(color: Int): Int { val hsv = FloatArray(3); Color.colorToHSV(color, hsv); return hsv[0].toInt() }
    private fun withAlpha(color: Int, alpha: Int) = (color and 0x00FFFFFF) or (alpha shl 24)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
