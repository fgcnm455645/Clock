# Vyra Clock

A starter Android widget project for a transparent 12-hour clock with a leading zero, imported TTF/OTF font support, and two-color gradient rendering.

## Build on GitHub from a phone
1. Create a new repository on GitHub (for example `VyraClock`).
2. Upload the contents of this folder to the repository root. Make sure `.github/workflows/android-build.yml` is included.
3. Open the repository's **Actions** tab and enable Actions if GitHub asks.
4. Run **Build Vyra Clock APK** from **Run workflow**, or push a commit to `main`.
5. Open the completed workflow run and download the `VyraClock-debug-apk` artifact. Extract it and install `app-debug.apk` on your phone.

## Notes
- The widget draws its text to a transparent bitmap. This allows custom fonts and a horizontal two-color gradient while keeping the widget background transparent.
- Use the launcher widget picker to add the widget. LockStar compatibility depends on the installed One UI / Good Lock version and whether it exposes third-party widgets on the lock screen.
- The first draft uses a small preset palette rather than a full color-picker UI. Font size is adjustable in the app; overall widget bounds can also be resized by the host if supported.
- This is an initial starter project, not yet device-tested. Please send the exact GitHub Actions build error if the first build fails and I'll help fix it.


## Version 0.2.0 notes
- App preview fits the requested font size to the preview area instead of clipping tall glyphs.
- Widget rendering fits against full font metrics to reduce clipping for decorative/tall fonts.
- Android widget host (including LockStar) still controls actual widget bounds. The app cannot force the host to make a widget arbitrarily tall; resize the widget in LockStar/home-screen widget settings for more vertical space.
- Build and device verification are still required in GitHub Actions and on a real Samsung device.
